package com.supplier.exception;

public class NotRecordFoundExecption extends RuntimeException {
	public NotRecordFoundExecption(String message) {
		super(message);
	}

}
